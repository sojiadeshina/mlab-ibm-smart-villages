//
//  QuestionTableViewCell.swift
//  LifeLine
//
//  Created by Gokul Swamy on 4/16/17.
//  Copyright © 2017 Gokul Swamy. All rights reserved.
//

import UIKit

class QuestionTableViewCell: UITableViewCell, UITextFieldDelegate {

    @IBOutlet weak var questionText: UILabel!
    @IBOutlet weak var responseField: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.responseField.endEditing(true)
        return false
    }

}
