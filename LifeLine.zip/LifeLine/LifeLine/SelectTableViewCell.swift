//
//  SelectTableViewCell.swift
//  LifeLine
//
//  Created by Gokul Swamy on 4/16/17.
//  Copyright © 2017 Gokul Swamy. All rights reserved.
//

import UIKit

class SelectTableViewCell: UITableViewCell {

    @IBOutlet weak var questionText: UILabel!
    @IBOutlet weak var responsePicker: UIPickerView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
