//
//  ProfileViewController.swift
//  LifeLine
//
//  Created by Gokul Swamy on 4/16/17.
//  Copyright © 2017 Gokul Swamy. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var table: UITableView!
    var questions: [String] = ["Age", "Occupation", "Education Level", "Marital Status", "Children", "Submit"]
    var options: [[String]] = [["Elementary", "Middle",  "Some High School", "Finished High School", "Undergraduate", "Graduate"], ["Single", "Married", "Widowed/Widower"], ["None", "1 to 2", "3 to 5", "6 or more"]]
    var cells: [String: UITableViewCell] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
        table.backgroundColor = #colorLiteral(red: 0.6024761796, green: 0.3159704804, blue: 0.8579155803, alpha: 1)
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ProfileViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view.
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return questions.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return options[pickerView.tag].count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        let str = NSAttributedString(string: options[pickerView.tag][row], attributes: [NSFontAttributeName:UIFont(name: "Helvetica", size: 15.0)!,NSForegroundColorAttributeName:UIColor.white])
        return str
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch questions[indexPath.row] {
        case "Age":
            let cell = tableView.dequeueReusableCell(withIdentifier: "question", for: indexPath) as! QuestionTableViewCell
            cell.questionText.text = "Age"
            cell.responseField.keyboardType = UIKeyboardType.numberPad
            cell.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            cell.contentView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            let border = CALayer()
            let width = CGFloat(1.0)
            border.borderColor = UIColor.white.cgColor
            border.frame = CGRect(x: 0, y: cell.responseField.frame.size.height - width, width:  cell.responseField.frame.size.width, height: cell.responseField.frame.size.height)
            border.borderWidth = width
            cell.responseField.layer.addSublayer(border)
            cell.responseField.layer.masksToBounds = true
            cells["Age"] = cell
            return cell
        case "Occupation":
            let cell = tableView.dequeueReusableCell(withIdentifier: "question", for: indexPath) as! QuestionTableViewCell
            cell.questionText.text = "Occupation"
            cell.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            cell.contentView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            let border = CALayer()
            let width = CGFloat(1.0)
            border.borderColor = UIColor.white.cgColor
            border.frame = CGRect(x: 0, y: cell.responseField.frame.size.height - width, width:  cell.responseField.frame.size.width, height: cell.responseField.frame.size.height)
            border.borderWidth = width
            cell.responseField.layer.addSublayer(border)
            cell.responseField.layer.masksToBounds = true
            cells["Occupation"] = cell
            return cell
        case "Education Level":
            let cell = tableView.dequeueReusableCell(withIdentifier: "select", for: indexPath) as! SelectTableViewCell
            cell.questionText.text = "Education Level"
            cell.responsePicker.tag = 0
            cell.responsePicker.dataSource = self
            cell.responsePicker.delegate = self
            cell.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            cell.contentView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            cells["Education Level"] = cell
            return cell
        case "Marital Status":
            let cell = tableView.dequeueReusableCell(withIdentifier: "select", for: indexPath) as! SelectTableViewCell
            cell.questionText.text = "Marital Status"
            cell.responsePicker.tag = 1
            cell.responsePicker.dataSource = self
            cell.responsePicker.delegate = self
            cell.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            cell.contentView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            cells["Marital Status"] = cell
            return cell
        case "Children":
            let cell = tableView.dequeueReusableCell(withIdentifier: "select", for: indexPath) as! SelectTableViewCell
            cell.questionText.text = "Children"
            cell.responsePicker.tag = 2
            cell.responsePicker.dataSource = self
            cell.responsePicker.delegate = self
            cell.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            cell.contentView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            cells["Children"] = cell
            return cell
        default:
            let cell = tableView.dequeueReusableCell(withIdentifier: "submit", for: indexPath)
            cell.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            cell.contentView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            return cell
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var profile: [String: String] = [:]
        for s in ["Age", "Occupation", "Education Level", "Marital Status", "Children"]{
            let cell = cells[s]
            if cell is QuestionTableViewCell{
                profile[s] = (cell as! QuestionTableViewCell).responseField.text
            }
            if cell is SelectTableViewCell{
                let row = (cell as! SelectTableViewCell).responsePicker.selectedRow(inComponent: 0)
                let tag = (cell as! SelectTableViewCell).responsePicker.tag
                profile[s] = options[tag][row]
            }
        }
        (segue.destination as! InterviewViewController).profile = profile
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
