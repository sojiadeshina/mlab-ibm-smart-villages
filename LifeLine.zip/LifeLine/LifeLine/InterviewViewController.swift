//
//  InterviewViewController.swift
//  LifeLine
//
//  Created by Gokul Swamy on 4/23/17.
//  Copyright © 2017 Gokul Swamy. All rights reserved.
//

import UIKit

class InterviewViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextViewDelegate {

    var profile: [String: String] = [:]
    var options = ["Physical Illness", "Mental Health", "Domestic Abuse", "Financial"]
    
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var textBox: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print(profile)
        pickerView.dataSource = self
        pickerView.delegate = self
        textBox.text = "Type or speak."
        textBox.delegate = self
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(InterviewViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)

        // Do any additional setup after loading the view.
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        textView.text = nil
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Type or speak."
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return options.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        let str = NSAttributedString(string: options[row], attributes: [NSFontAttributeName:UIFont(name: "Helvetica", size: 15.0)!,NSForegroundColorAttributeName:UIColor.white])
        return str
    }
    
    @IBAction func postToGoogle(_ sender: Any) {
        profile["Main Grievance"] = options[pickerView.selectedRow(inComponent: 0)]
        profile["More Info"] = textBox.text
        var val = ""
        var keys = ["Age", "Occupation", "Education Level", "Marital Status", "Children", "Main Grievance", "More Info"]
        for key in keys{
            val = val + profile[key]! + "_"
        }
        do{
            var address = "https://maker.ifttt.com/trigger/ibm_form_submitted/with/key/c0hliGRfxG_QheirL8Jf8s?value1=" + val
            var url = address.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
            var request = URLRequest(url: URL(string: url!)!)
            //App Transport Security blocks http:// connections, disable if needed
            request.httpMethod = "POST" //"GET", ...
            request.addValue(val, forHTTPHeaderField: "value1")
            URLSession.shared.dataTask(with: request) { data, response, error in
                if error != nil {
                    //Your HTTP request failed.
                    print(error?.localizedDescription)
                } else {
                    //Your HTTP request succeeded
                    print(String(data: data!, encoding: String.Encoding.utf8))
                }
                }.resume()
        }
        catch {
            print("incompatable body")
        }

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
